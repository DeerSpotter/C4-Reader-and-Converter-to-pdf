LM_LICENSE_FILE=$OMNIMARK_DIR/license.dat
export LM_LICENSE_FILE
#Above two lines needed for OMNIMARK to run on JCALS
#For some reason these need to be at the top of the file????


echo ""
echo " ** Running OmniMark programs ** "
echo ""

38784STD-BV8_index.sh $1

clear

echo ""
echo " ** Beginning final composition ** "
echo ""

DLcomposer -i index.sgml -n /jcals/wss_data/sgml_applications/FOSIs/$2.fosi -p output.ps -L index2.sgml -R -A

cp output.ps $2_index_after_change.ps

cp index2.sgml $2_index_after_change.sgml

rm -f output.ps
rm -f index.sgml
rm -f index2.sgml
rm -f omni.inputs


echo ""
echo " ** PROCESSING IS COMPLETE **"
echo ""

echo ""
echo " Final postscript is:  $2_index_after_change.ps "
echo ""
echo " Final tagged instance is:  $2_index_after_change.sgml "
echo ""

