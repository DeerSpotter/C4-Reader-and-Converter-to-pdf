LM_LICENSE_FILE=$OMNIMARK_DIR/license.dat
export LM_LICENSE_FILE
#Above two lines needed for OMNIMARK to run on JCALS
#For some reason these need to be at the top of the file????

#  SHELL SCRIPT calls programs to generate the acronym list for MIL-STD-38784
#   - two programs called:  38784STD-BV3_acronymlist1.xom and 38784STD-BV3_acronymlist2.xom
#   last modified by Barbara Jones  10 March 1999

omnimark -s  /jcals/wss_data/sgml_applications/services/omniprograms/38784STD-BV3_acronymlist1.xom  /jcals/wss_data/sgml_applications/services/library/28001con.syn $1 -of list.out -library /jcals/wss_data/sgml_applications/services/library/wndlibrary.txt

omnimark -s  /jcals/wss_data/sgml_applications/services/omniprograms/38784STD-BV8_acronymlist2.xom /jcals/wss_data/sgml_applications/services/library/28001con.syn $1 -of $1.acrm -library /jcals/wss_data/sgml_applications/services/library/wndlibrary.txt -define read $1 -define read2 list.out

rm -f list.out

