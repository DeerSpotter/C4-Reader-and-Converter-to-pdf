TABLES

These OmniMark scripts are designed to make use of the new "continued" attribute
on tables to help with the continued footnote problem. The script will split
tables that span more then one page into separate tables so Datalogics can
place the table footnotes on the correct page. The script should be invoked by
typing:

	38784STD-BV8_generate_table.sh filename.ext dss

	where:	38784STD-BV8_generate_index.sh is the name of the script,
		filename.ext is the name of the instance you want to process,
		and dss is the version of the dss you are using (e.g., 38784STD-BV8)

The script is set to loop if needed to ensure that the table breaks happen at the
appropriate place and will combine the tables if they were accidentally broken in
the wrong place. For large books, this may take a long time as one iteration requires
4 compositions and 3 script runs. The longest time required for any test document
required one loop, 6 compositions, and 6 script runs.

	*************************************************************************
	*
	*
	*  	FOR ANY PROBLEMS OR QUESTIONS WITH THE EXECUTION OF
	*	THESE SCRIPTS PROGRAMS, PLEASE CONTACT:
	*
	*		TOM PATTERSON
	*		AF DFSG/SBP
	*		thomas.patterson@wpafb.af.mil
	*
	*
	*************************************************************************






SCRIPT:		38784STD-BV8_generate_table.sh

PROGRAMS:	38784STD-BV8_table.xom
		38784STD-BV8_combine_table.xom

