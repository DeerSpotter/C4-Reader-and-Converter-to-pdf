LM_LICENSE_FILE=$OMNIMARK_DIR/license.dat
export LM_LICENSE_FILE
#Above two lines needed for OMNIMARK to run on JCALS
#For some reason these need to be at the top of the file????


omnimark -s  /jcals/wss_data/sgml_applications/services/omniprograms/38784STD-BV8_primary_index.xom  /jcals/wss_data/sgml_applications/services/library/28001con.syn $1 -of prindex.out -library /jcals/wss_data/sgml_applications/services/library/wndlibrary.txt

omnimark -s  /jcals/wss_data/sgml_applications/services/omniprograms/38784STD-BV8_secondary_index.xom /jcals/wss_data/sgml_applications/services/library/28001con.syn $1 -of secindex.out -library /jcals/wss_data/sgml_applications/services/library/wndlibrary.txt

omnimark -s  /jcals/wss_data/sgml_applications/services/omniprograms/38784STD-BV8_alphabetical_index.xom  /jcals/wss_data/sgml_applications/services/library/28001con.syn $1 -of finalindex.out -library /jcals/wss_data/sgml_applications/services/library/wndlibrary.txt -define inputfile $1 -define read1 prindex.out -define read2 secindex.out

rm -f prindex.out
rm -f secindex.out
cp finalindex.out index.sgml
rm -f finalindex.out
