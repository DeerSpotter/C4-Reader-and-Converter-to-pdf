38784STD-BV8 Numerical Index

The Numerical Index is a sorted list of part numbers and their associated
figure and index numbers used in the Illustrated Parts Breakdown Chapter 
tables in 38784STD-BV8.  OmniMark will automatically generate this list 
using data tagged throughout the manual.  It is assumed that your system 
administrator has installed OmniMark on your system and that all scripts 
and programs have been copied onto your system and modified to fit your 
specific site environment.

No additional tagging is necessary to produce this list.  All that is 
required by the author is to insert the start tag for numerical index with
the attribute of autobuild="1".  For example:

	<numindx autobuild="1">
	
Do include any other attributes applicable to your instance.
DO NOT include the end tag for numindx or the tag numgrp. Both will
	be generated and placed by the OmniMark program.
	
From the command line, type:

	38784STD-BV8_num_index.sh filename.ext
	
	where:	38784STD-BV8_num_index.sh is the name of the script, and
		filename.ext is the name of the instance you want to process
		
		
This script will call two programs needed to produce a numerical index.  The
first pulls all figure/index numbers and partno tags from the ipb chapter in 
the instance and sorts them in numerical order. The second program places
the sorted list within the numerical index tags.  Again, this is done
automatically, with no author effort.  

The final output of the program is a file called:  numindex_final.sgml  which
represents your instance file with a new, additional index.
This file can now be renamed or used as an input to compose using DLcomposer.
To ensure data integrity, it is advised that you maintain your original 
instance at all times.



	*************************************************************************
	*
	*
	*  	FOR ANY PROBLEMS OR QUESTIONS WITH THE EXECUTION OF
	*	THESE SCRIPTS PROGRAMS, PLEASE CONTACT:
	*
	*		TOM PATTERSON
	*		AF DFSG/SBP
	*		thomas.patterson@wpafb.af.mil
	*
	*************************************************************************






SCRIPT NAME:	38784STD-BV8_num_index.sh

PROGRAMS:	38784STD-BV8_num_index1.xom
		38784STD-BV8_num_index2.xom
		
