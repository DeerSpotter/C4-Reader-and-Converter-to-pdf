LM_LICENSE_FILE=$OMNIMARK_DIR/license.dat
export LM_LICENSE_FILE
#Above two lines needed for OMNIMARK to run on JCALS
#For some reason these need to be at the top of the file????

#  SHELL SCRIPT calls programs to generate the reference designator index for the illustrated
#	parts breakdown chapter which occurs in the combined 38784STD-BV4 manual
#   - two programs called:  38784STD-BV4_refdes_sssn1.xom and 38784STD-BV4_refdes2.xom
#   last modified by Barbara Jones 24 March 2000

echo ""
echo " ** Creating Reference Designator Index ** "
echo ""


omnimark -s  /jcals/wss_data/sgml_applications/services/omniprograms/38784STD-BV8_refdes_sssn1.xom  /jcals/wss_data/sgml_applications/services/library/28001con.syn $1 -of refdessssnlist.out -library /jcals/wss_data/sgml_applications/services/library/wndlibrary.txt

omnimark -s  /jcals/wss_data/sgml_applications/services/omniprograms/38784STD-BV8_refdes2.xom /jcals/wss_data/sgml_applications/services/library/28001con.syn $1 -of refdes_sssn_final.sgml -library /jcals/wss_data/sgml_applications/services/library/wndlibrary.txt -define read $1 -define read2 refdessssnlist.out

rm -f refdessssnlist.out
 
