LM_LICENSE_FILE=$OMNIMARK_DIR/license.dat
export LM_LICENSE_FILE
#Above two lines needed for OMNIMARK to run on JCALS
#For some reason these need to be at the top of the file????

#  SHELL SCRIPT calls programs to generate the numerical index for the illustrated
#	parts breakdown chapter in MIL-STD-38784
#   - two programs called:  38784STD-BV4_sssn1.xom and 38784STD-BV4_sssn2.xom
#   last modified by Barbara Jones  12 April 2000

echo ""
echo " ** Creating Reference Designator Index ** "
echo ""

omnimark -s  /jcals/wss_data/sgml_applications/services/omniprograms/38784STD-BV8_sssn1.xom  /jcals/wss_data/sgml_applications/services/library/28001con.syn $1 -of sssnlist.out -library /jcals/wss_data/sgml_applications/services/library/wndlibrary.txt

omnimark -s  /jcals/wss_data/sgml_applications/services/omniprograms/38784STD-BV4_sssn2.xom /jcals/wss_data/sgml_applications/services/library/28001con.syn $1 -of sssn_final.sgml -library /jcals/wss_data/sgml_applications/services/library/wndlibrary.txt -define read $1 -define read2 sssnlist.out

rm -f sssnlist.out
