LM_LICENSE_FILE=$OMNIMARK_DIR/license.dat
export LM_LICENSE_FILE
#Above two lines needed for OMNIMARK to run on JCALS
#For some reason these need to be at the top of the file????

#  SHELL SCRIPT calls programs to generate the numerical index for the illustrated
#	parts breakdown chapter in MIL-STD-38784
#   - two programs called:  38784STD-BV4_num_index1.xom and 38784STD-BV4_num_index2.xom
#   last modified by Barbara Jones  4 April 2000

omnimark -s  /jcals/wss_data/sgml_applications/services/omniprograms/38784STD-BV8_num_index1.xom  /jcals/wss_data/sgml_applications/services/library/28001con.syn $1 -of numindxlist.out -library /jcals/wss_data/sgml_applications/services/library/wndlibrary.txt

omnimark -s  /jcals/wss_data/sgml_applications/services/omniprograms/38784STD-BV8_num_index2.xom /jcals/wss_data/sgml_applications/services/library/28001con.syn $1 -of numindx_final.sgml -library /jcals/wss_data/sgml_applications/services/library/wndlibrary.txt -define read $1 -define read2 numindxlist.out

rm -f numindxlist.out

