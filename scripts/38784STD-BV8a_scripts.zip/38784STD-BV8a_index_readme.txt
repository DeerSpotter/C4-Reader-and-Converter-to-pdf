ALPHABETICAL INDEX

The Alphabetical Index is an alphabetical list of all the topics covered 
in the manual.  OmniMark will automatically generate this list using data
tagged throughout the manual.  It is assumed that your system administrator
has installed OmniMark on your system and that all scripts and programs have
been copied onto your system and modified to fit your specific site environment.

The author can determine what subjects are listed in the alphabetical index
by flagging important topics with a <prindex> tag.  Each primary topic
can have one or more secondary topics as determined by the author and they
can be tagged with the <secindex> tag.  Both tags have a required attribute
of pridnbr which is used to match each primary topics with its secondary
topics.

Tagging the content for index generation:

 

<para0 id="PARA 8.1" label="8.1"> <title>INTRODUCTION</title>
<para> <emphasis type="B">All data</emphasis> in this sample IPB forward is <emphasis type="B">NOTIONAL</emphasis>. Consult MIL-PRF-38807 for actual format and content requirements. <emphasis type="B">DO NOT USE THIS SAMPLE DATA FOR SPECIFIC  PROGRAM REQUIREMENTS!</emphasis> MIL-PRF-38807, 3.5.13 requires a manufacturers list when required by the acquiring activity. A manufacturers list shall be provided (see spec 6.2).  The list shall contain the <prindex pridnbr="c-1">Commercial and Government Entity (CAGE) code</prindex> and the name and address of all manufacturers whose CAGE codes are referenced  in the MPL.  <secindex pridnbr="c-1"> Customer CAGE Codes</secindex> for all parts are required.   <secindex pridnbr="c-1"> Customer Demands</secindex> in Scope are listed according to priority. <prindex pridnbr="m-1">Material safety data sheets (MSDS)</prindex> are included for use on the flight line.  <secindex pridnbr="m-1">Occupational safety and health act (OHSA)</secindex> rules apply to climbing on aircraft</para> </para0>

 

Style sheets/FOSI should produce the following index entries:

 

<index>
<letter>C</letter>
<prentry security="U"><topic para="8.1" page="8-1">Commercial and government entity (cage) code</topic></prentry>
<prentry><topic para="8.1" page="8-1">Customer Cage Codes</topic></prentry>
<prentry><topic para="8.1" page="8-1">Customer Demands</topic></prentry>
<letter>M</letter>
<prentry><topic para="8.1" page="8-1">Material safety data sheets (MSDS)</topic></prentry>
<secentry><topic para="8.1" page="8-1">Occupational safety and health act</topic></secentry>
</index>

 

The rendered index should look like this:

 

                                         C

Commercial and government entity (CAGE) 					8.1
    Customer CAGE codes    												8.1
    Customer Demands 															8.1

                                         M

Material safety data sheets (MSDS) 								8.1
    Occupational safety and health act (OSHA)  		8.1




Notice the end tags are required and must be included or the instance
will not parse.  These tags do not effect the composition or parsing of the 
instance.  They serve as flags to the OmniMark program to indicate that
these topics should appear in the index.

The index should be tagged with all applicable attributes and should
appear as:

	<index autobuild="1">
	
There are no required elements for the index so the initial instance
should contain an empty tag set as above.


From the command line, type:

	38784STD-BV8_generate_index.sh filename.ext dss
	
	where:	38784STD-BV8_generate_index.sh is the name of the script,
		filename.ext is the name of the instance you want to process,
		and dss is the version of the dss you are using (e.g., 38784STD-BV8)
		
		
This script will compose the instance using the "dss" FOSI and produce an 
output file containing page break tags needed to generate the index.  Then,
the script will call a subscript that will run three OmniMark programs that
will collect all primary and secondary topics, sort them alphabetically
and place the results in the instance within the index tag.  

The final output of the program is a file called:  "dss"_index.sgml
which represents your instance file with a new index and a postscript file
named:  "dss"_index.ps where "dss" is the dss specified.  To ensure data
integrity, it is advised that you maintain your original instance at all times.

*******************************************************************************
38784STD-BV8a Generating an Index After Running a Change Package
*******************************************************************************

The purpose of this script is so that point pages, if present, will appear in the index.  If you want to perform a change package on your initial instance, dash L the instance, like usual, make all changes, and run the "38784STD-BV8a_generate_index_after_change.sh" (see below).  Or, if you are performing a change package on an instance that already has page breaks and autobuild="1" in <index>, all that is required by the author is to run the "38784STD-BV8a_generate_index_after_change.sh" OmniMark script provided.
From the command line, type:

  38784STD-BV8a_generate_index_after_change.sh 38784_Change1.sgm(l)

	where:	38784STD-BV8a_generate_index_after_change.sh is the name of the script, and
					38784_Change1.sgm(l) is the name of the changed instance you want to process.

This script will call a program needed to produce the auto-generated index.  

The final output of the program is a file called:  "dss"_index_after_change.sgml
which represents your instance file with a new index and a postscript file
named:  "dss"_index_after_change.ps where "dss" is the dss specified. 
			
			** To ensure data integrity, it is advised that you maintain your original 
				 instance at all times. **

*******************************************************************************
NOTICE TO ALL USERS THAT DO NOT COMPOSE ON DATALOGICS COMPOSER.
*******************************************************************************

If you do not utilize the DataLogics composer - you can still process your
alphabetical index using the tagging method described above.  The difference
is in the script that you will process.

From the command line, type:

	38784STD-BV8_index.sh filename.ext
	
	where:	38784STD-BV8_index.sh is the name of the script, and
		filename.ext is the name of the instance you want to process
		
This script will produce an output file - index.sgml - that will 
contain the alphabetical index WITH empty tags for the paragraph and page numbers.
These will have to be manually tagged by the author.  However, the attributes will 
appear in the instance as place holders and need to be modified with the page
number for each primary and secondary topic.

**************************************************************************

SCRIPT:			38784STD-BV8_generate_index.sh

SUBSCRIPT:	38784STD-BV8_index.sh

PROGRAMS:		38784STD-BV8_primary_index.xom
						38784STD-BV8_secondary_index.xom
						38784STD-BV8_alphabetical_index.xom

************************************************************************
 
SCRIPT:			38784STD-BV8a_generate_index_after_change.sh

SUBSCRIPT:	38784STD-BV8_index.sh

PROGRAMS:		38784STD-BV8_primary_index.xom
						38784STD-BV8_secondary_index.xom
						38784STD-BV8_alphabetical_index.xom
		
		
*************************************************************************
*
*
*  	FOR ANY PROBLEMS OR QUESTIONS WITH THE EXECUTION OF
*		THESE SCRIPTS PROGRAMS, PLEASE CONTACT:
*
*		TMSS
*		sgmlsupport@wpafb.af.mil
*
*************************************************************************