VOLUMES

MIL-STD-38784 allows for users to develop manuals containing several
volumes.  The FOSI will generate the appropriate TOC, LOI, and LOTs, but
at the present time, there is no FOSI code to develop the individual
LEP's needed for each volume.  OmniMark programs were developed to 
allow the users to autogenerate the MAJORITY of the pages needed 
in the LEP and to place that LEP tagged data within the instance.

MIL-STD-38784 requires a full LEP for the entire manual and it should appear in
the first volume of a manual.  The FOSI will support the full LEP by using the
standard LEP and LEPCONTENTS tags.  However, for any subsequent volumes, each
LEP should only contain the pages for that volume.  Follow these guidelines
to produce a proper LEP for each volume. 


1)	Determine whether your volumes will contain volume page numbers
	i.e., 3-2-1 (volume number 3, chapter 2, page 1).  If this is
	required for your manual, the volpages attribute on each <volume>
	tag should be set equal to "1".
	
	<volume volpages="1">
	
	If volpages are not required, the default would produce standard
	page numbers.

2)	Tag each volume with the tag <vollep> and any desired attributes.
	Within each <vollep> tag the following:	
	
	<vollepcontents autobuild="1">
	
	
3)	Run one of the following scripts depending upon your choice of page
	enumeration.

	a)	38784STD-BV8_volumes_lep.sh - 	which will generate the
			necessary LEPs using standard page numbers.
			
	b)	38784STD-BV8_volumes_volpages_lep.sh -	which will generate
			the necessary LEPs using the volume page numbering.

			
From the command line, type:  scriptname filename.ext dss

	where:	scriptname is the name of the script (a or b above),
		filename is the name of the sgml instance, and dss is
		the dss version to use (e.g, 38784STD-BV8)


	
The script will compose the instance and place page numbers within the 
instance for use by OmniMark.  Following composition, the script will call
a sub-script that will invoke two OmniMark programs that will collect and
sort the required data.  The script will compose the new, improved instance
and produce a final output.

The final output of the program is a file called:  final.sgml
which represents new your instance file.  This file can now be renamed or 
used as an input for another program.  To ensure data integrity, it is advised 
that you maintain your original instance at all times.



	*************************************************************************
	*
	*
	*  	FOR ANY PROBLEMS OR QUESTIONS WITH THE EXECUTION OF
	*	THESE SCRIPTS PROGRAMS, PLEASE CONTACT:
	*
	*		TOM PATTERSON
	*		AF DFSB/SBP
	*		thomas.patterson@wpafb.af.mil
	*
	*
	*************************************************************************






SCRIPT:		38784STD-BV8_volumes_lep.sh

SUB-SCRIPT:	38784STD-BV8_lep.sh

PROGRAMS:	38784STD-BV5_volume_lep1.xom
		38784STD-BV8_volume_lep2.xom
		
SCRIPT:		38784STD-BV8_volumes_volpages_lep.sh

SUB-SCRIPT:	38784STD-BV8_volpages_lep.sh

PROGRAMS:	38784STD-BV5_volpages_lep1.xom
		38784STD-BV8_volume_lep2.xom
		
