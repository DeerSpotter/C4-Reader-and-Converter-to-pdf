LM_LICENSE_FILE=$OMNIMARK_DIR/license.dat
export LM_LICENSE_FILE
#Above two lines needed for OMNIMARK to run on JCALS
#For some reason these need to be at the top of the file????

cp $1 $1.bak

omnimark -s /jcals/wss_data/sgml_applications/services/omniprograms/38784STD-BV3_verstat.xom vsmatter.dat -of vsmatter.out

omnimark -s /jcals/wss_data/sgml_applications/services/omniprograms/38784STD-BV8_replace_verstat.xom /jcals/wss_data/sgml_applications/services/library/28001con.syn $1 -of $1.verstat -library /jcals/wss_data/sgml_applications/services/library/wndlibrary.txt -define read $1 -define read2 vsmatter.out

rm vsmatter.out

mv $1.verstat $1

