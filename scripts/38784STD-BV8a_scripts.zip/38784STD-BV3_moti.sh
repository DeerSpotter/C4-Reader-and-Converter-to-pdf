LM_LICENSE_FILE=$OMNIMARK_DIR/license.dat
export LM_LICENSE_FILE
# Above two lines needed for OMNIMARK to run on JCALS
# For some reason these need to be at the top of the file????

# AFCPO WPAFB
# Created by Andrew W. Sebastian & Barbara L. Jones - 3/31/1998
# Last modified - Barb Jones - 12/13/99

echo This generates a specific instance of $1, called $2

omnimark -s /jcals/wss_data/sgml_applications/services/omniprograms/38784STD-BV3_normal_moti.xom /jcals/wss_data/sgml_applications/services/library/28001con.syn $1 -library /jcals/wss_data/sgml_applications/services/library/wndlibrary.txt -of $2 -define inputfile $1

if [ "$?" -ne "0" ]
then
	echo "An error has occured while processing your instance."
	echo "Before running 38784STD-BV3_moti.sh again, try using the following command:"
	echo "parsenosyn "$1""
	exit 1
fi

#echo DONE!
