#! /bin/csh -f

setenv LM_LICENSE_FILE $OMNIMARK_DIR/license.dat
set lp = 0
#export LM_LICENSE_FILE
#Above two lines needed for OMNIMARK to run on JCALS
#For some reason these need to be at the top of the file????

echo " Processing instance for continued table footnotes"
echo ""

echo ""
echo " ** Beginning initial DLcomposer composition **"
echo ""

DLcomposer -i $1 -n /jcals/wss_data/sgml_applications/FOSIs/$2.fosi -p output.ps -L omni.inputs

loop:

echo ""
echo " ** Running OmniMark Split Table Program ** "
echo ""

omnimark -s  /jcals/wss_data/sgml_applications/services/omniprograms/38784STD-BV8_table.xom  /jcals/wss_data/sgml_applications/services/library/28001con.syn omni.inputs -of table.sgml -library /jcals/wss_data/sgml_applications/services/library/wndlibrary.txt -define inputfile omni.inputs

echo ""
echo " ** Beginning intermediate composition ** "
echo ""

DLcomposer -i table.sgml -n /jcals/wss_data/sgml_applications/FOSIs/$2.fosi -p $2_table.ps -L omni.second.inputs

echo ""
echo " ** Running Omnimark Split Table Program ** "
echo ""

omnimark -s  /jcals/wss_data/sgml_applications/services/omniprograms/38784STD-BV8_table.xom  /jcals/wss_data/sgml_applications/services/library/28001con.syn omni.second.inputs -of table.sgml -library /jcals/wss_data/sgml_applications/services/library/wndlibrary.txt -define inputfile omni.second.inputs

echo ""
echo " ** Beginning intermediate composition ** "
echo ""

DLcomposer -i table.sgml -n /jcals/wss_data/sgml_applications/FOSIs/$2.fosi -p $2_table.ps -L omni.third.inputs

echo ""
echo " ** Running Omnimark Combine Table Program ** "
echo ""

omnimark -s  /jcals/wss_data/sgml_applications/services/omniprograms/38784STD-BV8_combine_table.xom  /jcals/wss_data/sgml_applications/services/library/28001con.syn omni.third.inputs -of omni.inputs -library /jcals/wss_data/sgml_applications/services/library/wndlibrary.txt -define inputfile omni.third.inputs

if (-f combined) then
	rm -f combined
	goto loop
endif

echo ""
echo " ** Beginning final composition ** "
echo ""

DLcomposer -i omni.inputs -n /jcals/wss_data/sgml_applications/FOSIs/$2.fosi -p $2_table.ps

cp table.sgml $2_table.sgml

rm -f output.ps
rm -f table.sgml
rm -f omni.*inputs


echo ""
echo " ** PROCESSING IS COMPLETE **"
echo ""

echo ""
echo " Final postscript is:  $2_table.ps "
echo ""
echo " Final tagged instance is:  $2_table.sgml "
echo ""

