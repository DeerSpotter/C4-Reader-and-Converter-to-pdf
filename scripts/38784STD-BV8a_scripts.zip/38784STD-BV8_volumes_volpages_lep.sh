echo " Processing instance for MIL-STD-38784 Volumes"
echo ""

echo ""
echo " ** Beginning initial DLcomposer composition **"
echo ""

DLcomposer -i $1 -n /jcals/wss_data/sgml_applications/FOSIs/$2.fosi -p output.ps -L first.omni.inputs

echo ""
echo " ** Running first set of OmniMark programs ** "
echo ""

38784STD-BV8_volpages_lep.sh first.omni.inputs

echo ""
echo " ** Beginning final composition **"
echo ""

DLcomposer -i final.sgml -n /jcals/wss_data/sgml_applications/FOSIs/$2.fosi -p final.ps

rm -f output.ps
rm -f first.omni.inputs

echo ""
echo " ** PROCESSING IS COMPLETE **"
echo ""

echo ""
echo " Final postscript is:  final.ps "
echo ""
echo " Final tagged instance is:  final.sgml "
echo ""

