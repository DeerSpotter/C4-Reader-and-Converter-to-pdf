ACRONYM LIST

The Acronym List, located in the front matter of each manual, is an
alphabetical list of all the acronyms used in the manual.  OmniMark will 
automatically generate this list using data tagged throughout the manual.  It
is assumed that your system administrator has installed OmniMark on your system
and that all scripts and programs have been copied onto your system and 
modified to fit your specific site environment.

Each acronym that is required to appear in the acronym list should be tagged
within the instance using the <acronym> start tag and the associated 
term and def.  Notice the end tag for <acronym> is required and must be included 
or the instance will not parse.  These tags do not effect the composition or parsing 
of the instance.  They serve as flags to the OmniMark program to indicate that this 
acronym and its associated term and definition should appear in the acronym list. Below 
is the content model for acronym:

	<acronym	- - (def, term)  - (acronym | %exclus) >

To automatically generate the acronym list reference the list in your instance with the 
following tag and autobuild attribute:

	<acronymlist autobuild="1">
	
This will build tagged content in your instance for the acronym list, starting from the 
point it is referenced, that follows the current content model which is:

	<!ELEMENT acronymlist	- o  (acronymrow+ | (term, def)+)   -(acronym | %exclus;) >


From the command line, type:

	38784STD-BV8_acronym.sh filename.ext
	
	where:	38784STD-BV8_acronym.sh is the name of the script, and
		filename.ext is the name of the instance you want to process
		
		
This script will call two programs needed to produce an alphabetical acronym
list.  The first pulls all acronyms from the instance and sorts them in
alphabetical order.  The second program places the sorted list within the
acronymlist tags.  

The final output of the program is a file called:  filename.ext.acrm  which
represents your instance file with a new, additional extension of .acrm .  
This file can now be renamed or used as an input to compose using DLcomposer.
To ensure data integrity, it is advised that you maintain your original 
instance at all times.



	*************************************************************************
	*
	*
	*  	FOR ANY PROBLEMS OR QUESTIONS WITH THE EXECUTION OF
	*	THESE SCRIPTS PROGRAMS, PLEASE CONTACT:
	*
	*		TOM PATTERSON
	*		AF TMSS
	*		thomas.patterson@wpafb.af.mil
	*
	*************************************************************************

SCRIPT:		38784STD-BV8_acronym.sh

PROGRAMS:	38784STD-BV3_acronymlist1.xom
		38784STD-BV8_acronymlist2.xom


