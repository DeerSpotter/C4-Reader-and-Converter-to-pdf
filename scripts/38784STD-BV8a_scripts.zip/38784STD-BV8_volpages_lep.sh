LM_LICENSE_FILE=$OMNIMARK_DIR/license.dat
export LM_LICENSE_FILE
#Above two lines needed for OMNIMARK to run on JCALS
#For some reason these need to be at the top of the file????

omnimark -s  /jcals/wss_data/sgml_applications/services/omniprograms/38784STD-BV5_volpages_lep1.xom  /jcals/wss_data/sgml_applications/services/library/28001con.syn $1 -of vollep1.out -library /jcals/wss_data/sgml_applications/services/library/wndlibrary.txt

omnimark -s  /jcals/wss_data/sgml_applications/services/omniprograms/38784STD-BV8_volume_lep2.xom /jcals/wss_data/sgml_applications/services/library/28001con.syn $1 -of vollep2.out -library /jcals/wss_data/sgml_applications/services/library/wndlibrary.txt -define readfile vollep1.out -define read $1

cp vollep2.out final.sgml

rm vollep2.out
