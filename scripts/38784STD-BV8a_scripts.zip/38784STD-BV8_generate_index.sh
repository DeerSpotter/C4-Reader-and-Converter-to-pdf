LM_LICENSE_FILE=$OMNIMARK_DIR/license.dat
export LM_LICENSE_FILE
#Above two lines needed for OMNIMARK to run on JCALS
#For some reason these need to be at the top of the file????

echo " Processing instance for alphabetical index"
echo ""

echo ""
echo " ** Beginning initial DLcomposer composition **"
echo ""

DLcomposer -i $1 -n /jcals/wss_data/sgml_applications/FOSIs/$2.fosi -p output.ps -L omni.inputs

clear

echo ""
echo " ** Running OmniMark programs ** "
echo ""

38784STD-BV8_index.sh omni.inputs

clear

echo ""
echo " ** Beginning final composition ** "
echo ""

DLcomposer -i index.sgml -n /jcals/wss_data/sgml_applications/FOSIs/$2.fosi -p output.ps 


cp output.ps $2_index.ps

cp index.sgml $2_index.sgml

rm -f output.ps
rm -f index.sgml
rm -f omni.inputs


echo ""
echo " ** PROCESSING IS COMPLETE **"
echo ""

echo ""
echo " Final postscript is:  $2_index.ps "
echo ""
echo " Final tagged instance is:  $2_index.sgml "
echo ""

