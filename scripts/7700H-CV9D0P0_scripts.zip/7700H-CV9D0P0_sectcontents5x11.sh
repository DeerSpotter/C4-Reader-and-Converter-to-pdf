echo ""
echo ""
echo "  Processing instance for MIL-PRF-7700G Appendix C"
echo "            Flight Crew Checklist"
echo ""

echo ""
echo "  Running initial DLcomposer composition  "
echo "    to obtain preliminary page breaks  "
echo ""
echo ""

DLcomposer -i $1 -n /jcals/wss_data/sgml_applications/FOSIs/7700H-CV9D0P05x11.fosi -p output.ps -L first.omni.inputs
#DLcomposer -i $1 -n /home/users/sraney/7700G/7700C/V6aD3P0/7700G-CV6aD3P05x11.fosi -p output.ps -L first.omni.inputs

echo ""
echo ""
echo "   Begin processing   "
echo ""
echo ""

7700G-CV6D0P0_secttoc.sh first.omni.inputs


#Remove page breaks from output

#CCB #:  7700-A02093-01  Script left out of intial v6 install.
7700G-CV6D0P0_removelabels.sh contents2.out

echo ""
echo ""
echo "   Recompose to reconfigure page breaks  "
echo ""
echo ""

DLcomposer -i contents2.out -n /jcals/wss_data/sgml_applications/FOSIs/7700H-CV9D0P05x11.fosi -p output.ps -L second.omni.inputs
#DLcomposer -i contents2.out -n /home/users/sraney/7700G/7700C/V6aD3P0/7700G-CV6aD3P05x11.fosi -p output.ps -L second.omni.inputs

rm output.ps

echo ""
echo ""
echo "   Generating Section TOCs  "
echo ""
echo ""

7700G-CV6D0P0_secttoc.sh second.omni.inputs

rm contents1.out

mv contents2.out final.sgml


#Remove page breaks from output

#CCB #:  7700-A02093-01  Script left out of intial v6 install.
7700G-CV6D0P0_removelabels.sh final.sgml

echo ""
echo ""
echo "   Final DLcomposer Composition  "
echo ""
echo ""

DLcomposer -i final.sgml -n /jcals/wss_data/sgml_applications/FOSIs/7700H-CV9D0P05x11.fosi -p final.ps
#DLcomposer -i final.sgml -n /home/users/sraney/7700G/7700C/V6aD3P0/7700G-CV6aD3P05x11.fosi -p final.ps

echo ""
echo ""
echo "   ** PROCESSING IS COMPLETE **"
echo ""

echo ""
echo " Final postscript is:  final.ps "
echo ""
echo " Final tagged instance is:  final.sgml "
echo ""
echo ""
