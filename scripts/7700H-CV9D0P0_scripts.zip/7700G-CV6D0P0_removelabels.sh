LM_LICENSE_FILE=$OMNIMARK_DIR/license.dat
export LM_LICENSE_FILE
#Above two lines needed for OMNIMARK to run on JCALS
#For some reason these need to be at the top of the file????

cp $1 source

omnimark -s /jcals/wss_data/sgml_applications/services/omniprograms/7700G-CV6D0P0_remove_labels.xom /jcals/wss_data/sgml_applications/services/library/28001con.syn source -of labelsgone.out -library /jcals/wss_data/sgml_applications/services/library/wndlibrary.txt -define read2 source
cp labelsgone.out $1
rm -f source
rm -f labelsgone.out
