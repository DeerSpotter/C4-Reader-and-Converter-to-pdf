LM_LICENSE_FILE=$OMNIMARK_DIR/license.dat
export LM_LICENSE_FILE
#Above two lines needed for OMNIMARK to run on JCALS
#For some reason these need to be at the top of the file????

omnimark -s /jcals/wss_data/sgml_applications/services/omniprograms/7700G-CV6D0P0_contents1.xom /jcals/wss_data/sgml_applications/services/library/28001con.syn $1 -of contents1.out -library /jcals/wss_data/sgml_applications/services/library/wndlibrary.txt

omnimark -s /jcals/wss_data/sgml_applications/services/omniprograms/7700G-CV6D0P0_contents2.xom /jcals/wss_data/sgml_applications/services/library/28001con.syn $1 -of contents2.out -library /jcals/wss_data/sgml_applications/services/library/wndlibrary.txt -define readfile contents1.out -define inputfile $1

