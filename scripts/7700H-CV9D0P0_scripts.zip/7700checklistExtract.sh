LM_LICENSE_FILE=$OMNIMARK_DIR/license.dat
export LM_LICENSE_FILE
#Above two lines needed for OMNIMARK to run on JCALS
#For some reason these need to be at the top of the file????

#  SHELL SCRIPT calls program to extract checklist from 7700 Appendix A flight
#  Manual.


omnimark -s /jcals/wss_data/sgml_applications/services/omniprograms/7700checklistExtract.xom /jcals/wss_data/sgml_applications/services/library/28001con.syn $1 -of $1.out -library /jcals/wss_data/sgml_applications/services/library/wndlibrary.txt

rm $1.out

