LM_LICENSE_FILE=$OMNIMARK_DIR/license.dat
export LM_LICENSE_FILE
#Above two lines needed for OMNIMARK to run on JCALS
#For some reason these need to be at the top of the file????

fosiLoc="/jcals/wss_data/sgml_applications/FOSIs/9977L-GV9D0P0.fosi"
xom1Loc="/jcals/wss_data/sgml_applications/services/omniprograms/v6/9977L-GV8aD0P0_mcarnum1.xom"
xom2Loc="/jcals/wss_data/sgml_applications/services/omniprograms/v6/9977L-GV8aD0P0_mcarnum2.xom"

#TESTING File Locations
#fosiLoc="9977L-GV9D0P0.fosi"
#xom1Loc="9977L-GV8aD0P0_mcarnum1.xom"
#xom2Loc="9977L-GV8aD0P0_mcarnum2.xom"



echo " Processing instance for MIL-PRF-9977L Appendix G"
echo ""

echo ""
echo " ** Running initial DLcomposer composition ** "
echo " ** with -L to obtain page breaks **"
echo ""

DLcomposer -i $1 -n $fosiLoc -p output.ps -L first.omni.inputs

omnimark -s  $xom1Loc  /jcals/wss_data/sgml_applications/services/library/28001con.syn first.omni.inputs -of mcarnum1.out -library /jcals/wss_data/sgml_applications/services/library/wndlibrary.txt

omnimark -s  $xom2Loc /jcals/wss_data/sgml_applications/services/library/28001con.syn first.omni.inputs -of mcarnum2.out -library /jcals/wss_data/sgml_applications/services/library/wndlibrary.txt -define inputfile first.omni.inputs -define readfile mcarnum1.out

echo ""
echo " ** Beginning second DLcomposer composition **"
echo " ** with -L to correct page breaks **"
echo ""

DLcomposer -i mcarnum2.out -n $fosiLoc -p output2.ps -L second.omni.inputs

omnimark -s  $xom1Loc  /jcals/wss_data/sgml_applications/services/library/28001con.syn second.omni.inputs -of mcarnum3.out -library /jcals/wss_data/sgml_applications/services/library/wndlibrary.txt

omnimark -s  $xom2Loc /jcals/wss_data/sgml_applications/services/library/28001con.syn second.omni.inputs -of final.sgml -library /jcals/wss_data/sgml_applications/services/library/wndlibrary.txt -define inputfile second.omni.inputs -define readfile mcarnum3.out

echo ""
echo " ** Beginning final DLcomposer composition **"
echo " ** with output from mcarnum programs **"
echo ""

DLcomposer -i final.sgml -n $fosiLoc

echo ""
echo " ** PROCESSING IS COMPLETE **"
echo ""

echo ""
echo " Final postscript is:  final.ps "
echo ""
echo " Final tagged instance is:  final.sgml "
echo ""

